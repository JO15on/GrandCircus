import { FilterSearchPipe } from './filter-search.pipe';

describe('FilterSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
