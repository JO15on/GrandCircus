"use strict"


 // Calls for the fight function to run for the game

let player1 = "Mitch";
let player2 = "Adam";
let player1Health = 100;
let player2Health = 100;
fight(player1, player2, player1Health, player2Health);