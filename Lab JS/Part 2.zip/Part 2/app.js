"use strict"

// Randomize damage for both player 1 and player 2
// for each rounds
const randomDamage = () => (Math.floor(Math.random()*11));

// Pick either option from randomDamage
const chooseOption = (opt1, opt2) => {
    return Math.round(Math.random()) ? opt1  : opt2;
}

// Utilize randomDamage to sap player's health
function attackPlayer(health) {
    return health - randomDamage(1, 10);
}

// Log player's health in a console after each round
const logHealth = (player, health) => console.log(`${player} health: ${health}`);

// Log the end result of the game
const logDeath = (winner, loser) => console.log(`${winner} defeated ${loser}`);

// Runs an if else loop to confirm if a player is 
// still alive or dead
const isDead = health => {
    let isDead;
    if (health <= 0) {
        isDead = true;
    } else {
        isDead = false;
    }
return isDead;
}

// Runs the game which includes all of the functions
// that are already declared in this JS
function fight(player1, player2, player1Health, player2Health) {
    while (true) {
        let attacker =  chooseOption(player1, player2);
        if (attacker === player1) {
            player2Health = attackPlayer(player2Health);
            logHealth(player2, player2Health);
            if (isDead(player2Health)) {
                logDeath(player1, player2);
                break;
            }
        } else {
            player1Health = attackPlayer(player1Health);
            logHealth(player1, player1Health);
            if (isDead(player1Health)) {
                logDeath(player2, player1);
                break;
            }
        }
    }
}