"use strict"

class Car {
    constructor (fuelLevel = 100) {
        this.speed = 0;
        this.engineOn = false;
        this.fuelLevel = fuelLevel;
    }

    accelerate(fuelLevel, speed) {
        if (fuelLevel >= 1) {
            this.fuelLevel--;
            this.speed++;
        } 
    }

    brake(speed) {
        if (speed >= 0) {
            this.speed--;
        } 
    }

    turnCarOn() {
        if (this.engineOn === false) {
            this.engineOn = true;
            console.log("The engine is on")
        }
    }

    turnCarOff() {
        if (this.engineOn === true) {
            this.engineOn = false;
            console.log("The engine is off")
        }
    }

    refillFuel() {
        return this.fuelLevel = 100;
    }
    
}

const myCar = new Car(60);

console.log(myCar.refillFuel());
myCar.turnCarOn();
console.log(myCar.accelerate());
console.log(myCar.accelerate());
console.log(myCar.accelerate());
console.log(myCar.brake());
console.log(myCar.brake());
console.log(myCar.brake());
myCar.turnCarOff();