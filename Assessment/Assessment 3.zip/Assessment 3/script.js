"use strict"

function toggleColor(){
    if(document.body.style.background === "white") {
        document.body.style.background = "lightcoral";
    } else if(document.body.style.background = "lightcoral") {
        document.body.style.background = "white";
    }
}

function addBox(){
    let add = document.querySelector("#add-box");
    add.addEventListener('click', () => {
        const addDiv = document.getElementById("add-box").createElement('div');
        addDiv.innerText = "It is a div";
        addDiv.classList.add("box");
        addDiv.setAttribute('title', "I'm a box!");   
        for(i=0; i=addDiv.length-1; i++){
            console.log(i);
        document.body.append(addDiv);
    });
}

function removeBox(){
    const remove = document.querySelector(".box");
    remove.addEventListener('click', () =>{
        remove.removeChild();
    });
}