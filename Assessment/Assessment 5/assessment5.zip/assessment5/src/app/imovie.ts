export interface IMovie {
    title : string,
    releaseYear : number
}
