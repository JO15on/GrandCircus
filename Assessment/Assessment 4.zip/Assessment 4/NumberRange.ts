export interface NumberRange {
    low: number;
    high: number;
}